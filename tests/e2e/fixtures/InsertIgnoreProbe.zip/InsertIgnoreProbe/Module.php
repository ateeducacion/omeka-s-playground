<?php
namespace InsertIgnoreProbe;

use Laminas\ServiceManager\ServiceLocatorInterface;
use Omeka\Module\AbstractModule;

class Module extends AbstractModule
{
    public function install(ServiceLocatorInterface $services)
    {
        $services->get('Omeka\Connection')->executeStatement(
            'INSERT IGNORE INTO `setting` (`id`, `value`) VALUES (?, ?)',
            ['insert_ignore_probe', '"installed"']
        );
    }
}
