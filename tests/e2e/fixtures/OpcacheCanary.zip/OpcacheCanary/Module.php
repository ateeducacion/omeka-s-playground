<?php
namespace OpcacheCanary;

use Omeka\Module\AbstractModule;

// E2E fixture (tests/e2e/opcache-canary.spec.mjs). The module itself does
// nothing; it only ships canary.php under the web root.
class Module extends AbstractModule
{
}
