<?php
// E2E fixture for tests/e2e/opcache-canary.spec.mjs (ADR-0030 / ADR-0031).
// step=1: write a 10 s old target returning v1 and include it (OPcache may
//         store its bytecode: the file is older than file_update_protection).
// step=2: rewrite the same path to return v2 and include it again. With
//         opcache.validate_timestamps=0 a live file cache keeps serving v1.
$target = sys_get_temp_dir() . '/opcache-canary-target.php';
$step = isset($_GET['step']) ? (string) $_GET['step'] : '1';
if ($step === '1') {
    file_put_contents($target, "<?php return 'v1';");
    touch($target, time() - 10);
} else {
    file_put_contents($target, "<?php return 'v2';");
}
$value = include $target;
$status = function_exists('opcache_get_status') ? opcache_get_status(false) : false;
header('Content-Type: application/json');
echo json_encode([
    'step' => $step,
    'value' => $value,
    'php' => PHP_VERSION,
    'sapi' => PHP_SAPI,
    'validateTimestamps' => ini_get('opcache.validate_timestamps'),
    'blacklist' => ini_get('opcache.blacklist_filename'),
    'status' => $status === false ? false : [
        'enabled' => $status['opcache_enabled'] ?? null,
        'fileCacheOnly' => $status['file_cache_only'] ?? null,
    ],
]);
